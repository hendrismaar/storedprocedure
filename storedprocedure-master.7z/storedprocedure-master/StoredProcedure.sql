Create table Employees
(
	ID int primary key identity,
	FirstName nvarchar(50),
	LastName nvarchar(50),
	Gender nvarchar(50),
	Salary int
)
Go

Insert into Employees values ('Mark', 'Hastings', 'Male', 60000)
Insert into Employees values ('Steve', 'Pound', 'Male', 45000)
Insert into Employees values ('Ben', 'Hoskins', 'Male', 70000)
Insert into Employees values ('Philip', 'Hastigns', 'Male', 45000)
Insert into Employees values ('Mary', 'Lambeth', 'Female', 30000)
Insert into Employees values ('Valarie', 'Vikings', 'Female', 35000)
Insert into Employees values ('John', 'Stanmore', 'Male', 80000)

Create Procedure spSearchEmployees
@FirstName nvarchar(100),
@LastName nvarchar(100),
@Gender nvarchar(50),
@Salary int
As
Begin
Select * from Employees where
	(FirstName = @FirstName OR @FirstName IS NULL) AND
	(LastName = @LastName OR @LastName IS NULL) AND
	(Gender = @Gender OR @Gender IS NULL) AND
	(Salary = @Salary OR @Salary IS NULL)
End
Go

Declare @sql nvarchar(1000)
Declare @params nvarchar(1000)

Set @sql = 'Select * from Employees where FirstName=@FirstName and LastName=@LastNAme'
Set @params = '@FirstName nvarchar(100), @LastName nvarchar(100)'

Execute sp_executesql @sql, @params, @FirstName='Ben',@LastName='Hoskins'

Alter procedure spSearchEmployees
@FirstName nvarchar(100) = NULL,
@LastName nvarchar(100) = NULL,
@Gender nvarchar(50)= NULL,
@Salary int = NULL
As 
Begin
Select * from Employees where
	(FirstName = @FirstName OR @FirstName IS NULL) AND
	(LastName = @LastName OR @LastName IS NULL) AND
	(Gender = @Gender OR @Gender IS NULL) AND
	(Salary = @Salary OR @Salary IS NULL)
End
Go

