﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StoredProcedure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoredProcedure.Data
{
    public class StoredProcedureDbContext : DbContext
    {
        public StoredProcedureDbContext(DbContextOptions<StoredProcedureDbContext> options)
        : base(options) { }

        public DbSet<Employee> Employee { get; set; }
    }
}
